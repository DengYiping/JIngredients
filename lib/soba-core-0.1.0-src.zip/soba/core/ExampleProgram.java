package soba.core;

public interface ExampleProgram {

	public static final String CLASS_C = "soba/testdata/inheritance1/C";
	public static final String CLASS_D = "soba/testdata/inheritance1/D";
	public static final String CLASS_E = "soba/testdata/inheritance2/E";
	public static final String CLASS_F = "soba/testdata/inheritance2/F";
	public static final String CLASS_G = "soba/testdata/inheritance1/G";
	public static final String CLASS_H = "soba/testdata/inheritance2/H";
	public static final String CLASS_I = "soba/testdata/inheritance1/I";
	public static final String CLASS_J = "soba/testdata/inheritance1/J";
	public static final String CLASS_K = "soba/testdata/inheritance1/K";

	
}
