package soba.testdata.inheritance2;

import soba.testdata.inheritance1.C;

public abstract class L {

	public abstract C getC();
	
}
