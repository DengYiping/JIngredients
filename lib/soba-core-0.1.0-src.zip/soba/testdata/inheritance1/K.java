package soba.testdata.inheritance1;

public interface K extends I {

}
