package soba.testdata.inheritance1;

public interface I {

	public static final int x = 2;
	public void m();
}
