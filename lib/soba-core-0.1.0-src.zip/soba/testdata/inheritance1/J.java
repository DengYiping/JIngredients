package soba.testdata.inheritance1;

public interface J {

	public static final int x = 1;
}
